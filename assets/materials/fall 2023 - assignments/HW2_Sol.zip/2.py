import numpy as np


def convert_string_to_int(elements):
    new_array = []
    for element in elements:
        new_array.append(int(element))

    return new_array


def gram_schmidt(vectors):
    orthogonal_vectors = []
    for v in vectors:
        for u in orthogonal_vectors:
            v -= np.dot(u, v) / np.dot(u, u) * u
        orthogonal_vectors.append(v / np.linalg.norm(v))
    return orthogonal_vectors


n, m = input().split()
n = int(n)
m = int(m)

given_vectors = []

for i in range(n):
    given_vectors.append(convert_string_to_int(input().split(" ")))

orthogonal_vectors = gram_schmidt(given_vectors)
sorted_orthogonal_vectors = np.array(sorted(tuple(tuple(j for j in i) for i in orthogonal_vectors))[::-1])

for vector in sorted_orthogonal_vectors:
    x = ""
    for element in vector:
        x += f'{element:.3f}'
        x += " "
    x = x[:-1]
    print(x)
