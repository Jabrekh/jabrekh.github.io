import numpy as np


def convert_string_to_int(elements):
    new_array = []
    for element in elements:
        new_array.append(int(element))

    return new_array


def is_linearly_independent(vectors):
    matrix = np.array(vectors)
    num_vecs, _ = matrix.shape
    rank = np.linalg.matrix_rank(matrix)
    return rank == num_vecs


def is_affinely_independent(vectors):
    num_vectors = len(vectors)

    vector_dim = len(vectors[0])

    if any(len(vectors[i]) != vector_dim for i in range(1, num_vectors)):
        return False

    matrix = np.column_stack((vectors, np.ones(num_vectors)))
    rank = np.linalg.matrix_rank(matrix)

    return rank == num_vectors


def analyze_vectors(vectors):
    if is_linearly_independent(vectors):
        return "LINEARLY INDEPENDENT" 
    
    if is_affinely_independent(vectors):
        return "AFFINELY INDEPENDENT"

    return "DEPENDENT"


if __name__ == "__main__":

    n, m = input().split()
    n = int(n)
    m = int(m)

    given_vectors = []

    for i in range(n):
        given_vectors.append(convert_string_to_int(input().split(" ")))

    print(analyze_vectors(given_vectors))